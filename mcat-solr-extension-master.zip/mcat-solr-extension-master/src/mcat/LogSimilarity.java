package mcat;
import org.apache.lucene.index.FieldInvertState;
import org.apache.lucene.search.similarities.DefaultSimilarity;

public class LogSimilarity extends DefaultSimilarity {

	@Override
	
	
}
